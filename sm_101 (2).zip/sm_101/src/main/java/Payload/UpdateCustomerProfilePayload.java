package Payload;


public class UpdateCustomerProfilePayload {


    public static String UpdateCustomerProfilePayload = "{\"address\":{\n" +
            "\t\"customerId\":50878,\n" +
            "\t\"phoneNumber\":\"+9290078601\",\n" +
            "\t\"cityId\":\"1\",\n" +
            "\t\"building\":\"Build One\",\n" +
            "\t\"apartment\":\"22\",\n" +
            "\t\"area\":\"60\",\n" +
            "\t\"id\":\"\"},\n" +
            "\t\"customerContactNumbers\":[\n" +
            "\t\t{\"contactNumber\":\"+9290078601\",\n" +
            "\t\t\"contactType\":\"Mobile\",\n" +
            "\t\t\"isPreferred\":1}],\n" +
            "\t\t\"customerId\":26804,\n" +
            "\t\t\"firstName\":\"Aroma\",\n" +
            "\t\t\"lastName\":\"Gul\"}";





}
