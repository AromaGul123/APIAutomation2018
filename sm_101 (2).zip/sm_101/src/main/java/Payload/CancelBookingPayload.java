package Payload;


public class CancelBookingPayload {


    public static String CancelBookingPayload = "{\"comments\":null,\n" +
            "\"requestedBy\":\"customer\",\n" +
            "\"cancellationReason\":\"I will not be available on this day or time\",\n" +
            "\"statusId\":72,\n" +
            "\"bookingId\":45570,\n" +
            "\"sendEmailToCustomer\":1}";




}
