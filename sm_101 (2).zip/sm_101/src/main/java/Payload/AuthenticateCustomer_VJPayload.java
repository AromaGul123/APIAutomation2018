package Payload;


public class AuthenticateCustomer_VJPayload {


    public static String authenticatePayload = "{\n" +
            "    \"credentials\": \"8669bd5425844f459119f353d9652774BKfVLhkqhJmti6OCMvhEyFthNQzA1MiV\",\n" +
            "    \"attributes\": {\n" +
            "        \"phoneNumber\": \"+923331234567\",\n" +
            "        \"deviceInfo\": \"ios\",\n" +
            "        \"deviceUUID\": \"5aca3f8bc4617158\",\n" +
            "        \"appBuildNr\": \"270\",\n" +
            "        \"os\": \"9.3.2\",\n" +
            "        \"devicePushId\": \"B1FE5B24-EF91-43DE-B761-3B267EF749D0\"\n" +
            "    }\n" +
            "}";

}