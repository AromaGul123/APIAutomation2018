package Payload;


public class SoftBookingActivationPayload {


    public static String SoftBookingActivationPayload = "{\"bookingID\":\"33757\",\"creditCardModel\":{\"creditCardId\":\"\",\"paymentMethod\":\"CASH_ON_DELIVERY\"}}";




}
