package Payload;


public class RegisterUser_VJPayload {


    public static String registerPayload = "{\n" +
            "    \"username\" : \"irtaza10@vd.com\",\n" +
            "    \"password\": \"Vista123\",\n" +
            "    \"salutation\": \"Mr.\",\n" +
            "    \"firstName\": \"Irtaza10\",\n" +
            "    \"lastName\": \"Direct\",\n" +
            "    \"gender\": \"w\",\n" +
            "    \"phoneNumber\": \"+923331313130\",\n" +
            "    \"deviceId\": \"M3FL5B24-EF91-43DE-B761-3B267EF749D\",\n" +
            "    \"deviceType\": \"iso\",\n" +
            "    \"osVersion\": \"9.3.2\",\n" +
            "    \"city\": \"Karachi\",\n" +
            "\t\"countryName\": \"Pakistan\",\n" +
            "\t\"token\" : \"d0cc7db09d2846efa490cda6209e4656\",\n" +
            "    \"subscription\": \"true\",\n" +
            "    \"company\": \"VistaJet\",\n" +
            "    \"registrationReason\": 2,\n" +
            "    \"source\": \"customerapp\"\n" +
            "}";





}
