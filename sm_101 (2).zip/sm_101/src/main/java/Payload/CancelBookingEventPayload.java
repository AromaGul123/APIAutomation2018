package Payload;


public class CancelBookingEventPayload {


    public static String CancelBookingEventPayload = "{\"comments\":null,\n" +
            "\"requestedBy\":\"customer\",\n" +
            "\"cancellationReason\":\"I won't need cleaning on this day\",\n" +
            "\"statusId\":77,\n" +
            "\"eventId\":160960,\n" +
            "\"deliveryTimeInUtc\":\"\"}";




}
